<?php
include 'config.php';
include 'cms_core.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: admin.php");
    exit;
}

$sysVer   = getSystemVersion();
$cmsRoot  = realpath(__DIR__);
$msg      = '';
$msgType  = '';

function addFolderToZip(ZipArchive $zip, string $folder, string $base): void {
    $handle = opendir($folder);
    if (!$handle) return;
    while (($entry = readdir($handle)) !== false) {
        if ($entry === '.' || $entry === '..') continue;
        $fullPath = $folder . '/' . $entry;
        $relPath  = substr($fullPath, strlen($base) + 1);
        if (is_dir($fullPath)) {
            $zip->addEmptyDir($relPath);
            addFolderToZip($zip, $fullPath, $base);
        } elseif (is_file($fullPath)) {
            $zip->addFile($fullPath, $relPath);
        }
    }
    closedir($handle);
}

// ── Export ──────────────────────────────────────────────
if (isset($_POST['do_export'])) {
    $stamp   = date('Y-m-d_H-i-s');
    $zipName = 'backup_' . $stamp . '.zip';
    $tmpPath = sys_get_temp_dir() . '/' . $zipName;

    $zip = new ZipArchive();
    if ($zip->open($tmpPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        addFolderToZip($zip, $cmsRoot, $cmsRoot);
        $zip->close();

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zipName . '"');
        header('Content-Length: ' . filesize($tmpPath));
        readfile($tmpPath);
        unlink($tmpPath);
        exit;
    }
    $msg     = 'Failed to create ZIP archive.';
    $msgType = 'error';
}

// ── Import ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['import_zip']) && is_uploaded_file($_FILES['import_zip']['tmp_name'])) {
    $err = $_FILES['import_zip']['error'] ?? UPLOAD_ERR_NO_FILE;
    $ext = strtolower(pathinfo($_FILES['import_zip']['name'], PATHINFO_EXTENSION));

    if ($err !== UPLOAD_ERR_OK) {
        $msg     = 'Upload error (code ' . $err . ').';
        $msgType = 'error';
    } elseif ($ext !== 'zip') {
        $msg     = 'Only .zip files are accepted.';
        $msgType = 'error';
    } else {
        $zip = new ZipArchive();
        if ($zip->open($_FILES['import_zip']['tmp_name']) === true) {
            // Remove all existing files/folders first so it's a full replace
            $delIt = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($cmsRoot, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($delIt as $item) {
                if ($item->isDir()) {
                    @rmdir($item->getPathname());
                } else {
                    @unlink($item->getPathname());
                }
            }
            $zip->extractTo($cmsRoot);
            $zip->close();
            $msg     = 'All existing files removed and ZIP extracted to project root.';
            $msgType = 'success';
        } else {
            $msg     = 'Could not open uploaded ZIP.';
            $msgType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Backup — CMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(cms_asset_url('admin_style.css'), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="wp-admin-skin">
    <div class="wp-admin-shell">
        <header class="wp-admin-bar" role="banner">
            <div class="wp-admin-bar-row">
                <div class="wp-admin-bar-site">
                    <button type="button" class="wp-menu-toggle" id="wp-menu-toggle" aria-expanded="false" aria-controls="wp-admin-menu" aria-label="Open menu">
                        <span class="screen-reader-text">Menu</span>
                        <i class="fas fa-bars" aria-hidden="true"></i>
                    </button>
                    <div class="wp-admin-bar-brand">
                        <span class="wp-brand-mark" aria-hidden="true">A</span>
                        <div class="wp-brand-text">
                            <span class="wp-brand-name">Agentic CMS</span>
                            <span class="wp-brand-tag">flat-file workspace</span>
                        </div>
                    </div>
                </div>
                <div class="wp-admin-bar-secondary">
                    <a href="index.php" target="_blank" rel="noopener" class="wp-bar-visit"><i class="fas fa-external-link-alt" aria-hidden="true"></i><span>View site</span></a>
                    <span class="wp-bar-pill">v<?php echo htmlspecialchars($sysVer['ver']); ?></span>
                    <span class="wp-bar-user">
                        <span class="wp-bar-avatar" aria-hidden="true">A</span>
                        <span class="wp-bar-greet">Howdy, <strong>admin</strong></span>
                    </span>
                </div>
            </div>
        </header>

        <div class="wp-admin-frame">
            <div class="wp-admin-menu-backdrop" aria-hidden="true"></div>
            <nav class="wp-admin-menu" id="wp-admin-menu" aria-label="Main menu">
                <div class="menu-top">Navigation</div>
                <a href="admin.php"><i class="fas fa-file-alt" aria-hidden="true"></i> Pages</a>
                <a href="media_manager.php"><i class="fas fa-camera-retro" aria-hidden="true"></i> Media</a>
                <a href="backup.php" class="current"><i class="fas fa-cloud-download-alt" aria-hidden="true"></i> Backup</a>
                <a href="admin.php?tab=users"><i class="fas fa-users-cog" aria-hidden="true"></i> User Roles</a>
                <a href="admin.php?tab=config"><i class="fas fa-server" aria-hidden="true"></i> Server Config</a>
                <div class="menu-footer">
                    <a href="admin.php?logout=1"><i class="fas fa-power-off" aria-hidden="true"></i> Log Out</a>
                </div>
            </nav>

            <div class="wp-admin-main">
                <div class="wp-admin-toolbar">
                    <div class="wp-admin-toolbar-title">
                        <i class="fas fa-cloud-download-alt" aria-hidden="true"></i>
                        <span>Backup</span>
                    </div>
                </div>

                <div class="wp-admin-scroll">
                    <div class="wrap">

                        <?php if ($msg): ?>
                            <div class="notice notice-<?php echo $msgType === 'success' ? 'success' : 'error'; ?>">
                                <p><?php echo htmlspecialchars($msg); ?></p>
                            </div>
                        <?php endif; ?>

                        <div style="display:flex; flex-wrap:wrap; gap:16px;">

                            <!-- Export -->
                            <div class="postbox" style="flex:1; min-width:260px;">
                                <h2 class="postbox-header">Export</h2>
                                <div class="postbox-inner">
                                    <p style="margin:0 0 12px; font-size:13px; color:var(--ink3);">
                                        Download all project files and folders as a single <strong>.zip</strong> archive.
                                    </p>
                                    <form method="post">
                                        <button type="submit" name="do_export" class="button button-primary">
                                            <i class="fas fa-download" aria-hidden="true"></i> Download ZIP
                                        </button>
                                    </form>
                                </div>
                            </div>

                            <!-- Import -->
                            <div class="postbox" style="flex:1; min-width:260px;">
                                <h2 class="postbox-header">Import</h2>
                                <div class="postbox-inner">
                                    <p style="margin:0 0 12px; font-size:13px; color:var(--ink3);">
                                        Upload a <strong>.zip</strong> file. All existing files will be removed and replaced with the ZIP contents.
                                    </p>
                                    <form method="post" enctype="multipart/form-data">
                                        <input type="file" name="import_zip" accept=".zip" required style="margin-bottom:10px;">
                                        <br>
                                        <button type="submit" class="button button-primary">
                                            <i class="fas fa-upload" aria-hidden="true"></i> Upload &amp; Extract
                                        </button>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    (function () {
        var shell = document.querySelector('.wp-admin-shell');
        var toggle = document.getElementById('wp-menu-toggle');
        var backdrop = document.querySelector('.wp-admin-menu-backdrop');
        if (!shell || !toggle) return;
        function setOpen(open) {
            shell.classList.toggle('wp-menu-open', open);
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
        toggle.addEventListener('click', function () {
            setOpen(!shell.classList.contains('wp-menu-open'));
        });
        if (backdrop) {
            backdrop.addEventListener('click', function () { setOpen(false); });
        }
        document.querySelectorAll('#wp-admin-menu a[href]').forEach(function (a) {
            var h = a.getAttribute('href');
            if (h && h !== '#' && h.indexOf('#') !== 0) {
                a.addEventListener('click', function () { setOpen(false); });
            }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') { setOpen(false); }
        });
        var mq = window.matchMedia('(min-width: 783px)');
        function closeIfDesktop() { if (mq.matches) { setOpen(false); } }
        if (mq.addEventListener) { mq.addEventListener('change', closeIfDesktop); }
        else if (mq.addListener) { mq.addListener(closeIfDesktop); }
    })();
    </script>
</body>
</html>
