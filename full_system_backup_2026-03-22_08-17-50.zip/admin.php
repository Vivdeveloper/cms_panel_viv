<?php
include 'config.php';
include 'cms_core.php';

// Handle Logout
if (isset($_GET['logout'])) { session_destroy(); header("Location: admin.php"); exit; }

// Access Control
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    if (isset($_POST['auth_key']) && $_POST['auth_key'] === '12345') {
        $_SESSION['is_admin'] = true;
        header("Location: admin.php"); exit;
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8"><title>Admin Portal Login</title>
        <link rel="stylesheet" href="admin_style.css">
        <style>
            body { background-color: #f0f0f1; display: flex; align-items: center; justify-content: center; height: 100vh; font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif; }
            .login-card { background: #fff; width: 320px; padding: 24px; border: 1px solid #ccd0d4; box-shadow: 0 1px 3px rgba(0,0,0,.1); border-radius: 4px; }
            input { width: 100%; padding: 12px; border: 1px solid #8c8f94; border-radius: 4px; margin-bottom: 16px; box-sizing: border-box; font-size: 16px; outline: none; }
            button { width: 100%; background: #2271b1; color: #fff; padding: 12px; border-radius: 4px; border: none; font-weight: 600; cursor: pointer; }
        </style>
    </head>
    <body class="admin-body">
        <div class="login-card">
            <h2 style="font-size: 14px; color:#1d2327; margin-bottom: 20px; text-align: center; font-weight: 700;">AGENTIC CMS LOGIN</h2>
            <form method="POST">
                <input type="password" name="auth_key" placeholder="Password" required autofocus>
                <button type="submit">Log In</button>
            </form>
        </div>
    </body>
    </html>
    <?php exit;
}

$sysVer = getSystemVersion();
$allPages = getAllCMSPages();
$editData = null;
if (isset($_GET['edit'])) { $editData = getCMSPage($_GET['edit']); }

// User Management (New)
if (isset($_POST['add_user'])) {
    checkAdmin();
    createUser($_POST['username'], $_POST['role']);
    header("Location: admin.php?tab=users"); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pages - Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif; background: #f0f0f1; }
        .wp-wrapper { display: flex; height: 100vh; overflow: hidden; }
        
        /* SIDEBAR */
        .wp-sidebar { width: 160px; background: #26292c; display: flex; flex-direction: column; z-index: 1000; }
        .wp-sidebar a { color: #f0f0f1; text-decoration: none; padding: 12px 15px; font-size: 14px; display: block; border-left: 4px solid transparent; transition: 0.1s; }
        .wp-sidebar a:hover { background: #1d2327; color: #72aee6; }
        .wp-sidebar a.active { background: #1d2327; color: #fff; border-left-color: #72aee6; }
        
        /* CONTENT LAYOUT */
        .wp-main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .wp-header { height: 45px; background: #fff; border-bottom: 1px solid #ccd0d4; display: flex; align-items: center; padding: 0 20px; justify-content: space-between; }
        .wp-split { display: flex; flex: 1; overflow: hidden; }
        
        /* PANELS */
        .wp-panel { flex: 1; overflow-y: auto; background: #fff; padding: 25px; border-right: 1px solid #ccd0d4; display: none; }
        .wp-panel.active { display: block; }
        
        .page-table { width: 100%; border-collapse: collapse; }
        .page-table th { text-align: left; padding: 10px; border-bottom: 1px solid #ccd0d4; font-size: 13px; color: #1d2327; }
        .page-table td { padding: 12px 10px; border-bottom: 1px solid #f0f0f1; vertical-align: middle; }
        
        .row-actions { visibility: hidden; padding-top: 5px; font-size: 12px; }
        tr:hover .row-actions { visibility: visible; }
        .row-actions a { color: #2271b1; text-decoration: none; }
        .row-actions a.delete { color: #b32d2e; }
        
        /* EDITOR SIDEBAR */
        .wp-edit { width: 500px; background: #f6f7f7; border-left: 1px solid #ccd0d4; display: flex; flex-direction: column; }
        .edit-header { padding: 15px 20px; background: #fff; border-bottom: 1px solid #ccd0d4; display: flex; justify-content: space-between; align-items: center; }
        .edit-body { flex: 1; overflow-y: auto; padding: 25px; }
        
        .form-group { margin-bottom: 25px; }
        .form-group label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 8px; color: #1d2327; }
        .wp-input { width: 100%; border: 1px solid #8c8f94; padding: 10px; border-radius: 4px; font-size: 14px; outline: none; }
        .wp-input:focus { border-color: #2271b1; box-shadow: 0 0 0 1px #2271b1; }
        .wp-code { width: 100%; height: 220px; font-family: monospace; font-size: 12px; background: #fff; }
        
        .btn-wp { background: #2271b1; color: #fff; border: 1px solid #2271b1; padding: 8px 15px; border-radius: 3px; font-weight: 600; font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
        .btn-wp:hover { background: #135e96; }
        
        .status-badge { font-size: 10px; padding: 2px 6px; background: #e0f6e0; color: #008a20; border-radius: 2px; text-transform: uppercase; font-weight: 700; margin-left:10px; }
    </style>
</head>
<body>
    <div class="wp-wrapper">
        <div class="wp-sidebar">
            <div style="padding: 15px; color: #fff; font-weight: 800; font-size: 11px; opacity: 0.5;">CMS CONTROL</div>
            <a href="#" class="nav-btn active" onclick="switchMainTab('pages', event)"><i class="fas fa-file-alt" style="width:20px;"></i> Pages</a>
            <a href="media_manager.php"><i class="fas fa-camera-retro" style="width:20px;"></i> Media</a>
            <a href="sync_center.php"><i class="fas fa-cloud-download-alt" style="width:20px;"></i> Backup</a>
            <a href="#" class="nav-btn" onclick="switchMainTab('users', event)"><i class="fas fa-users-cog" style="width:20px;"></i> User Roles</a>
            <a href="#" class="nav-btn" onclick="switchMainTab('config', event)"><i class="fas fa-server" style="width:20px;"></i> Server Config</a>
            <div style="margin-top: auto;">
                <a href="?logout=1" style="color: #ffa8a8;"><i class="fas fa-power-off" style="width:20px;"></i> Log Out</a>
            </div>
        </div>

        <div class="wp-main">
            <div class="wp-header">
                <div style="font-size: 13px; font-weight: 600; color: #50575e;"><i class="fas fa-globe"></i> <a href="index.php" target="_blank" style="color:#2271b1; text-decoration:none;">View Website</a></div>
                <div style="font-size: 13px; color: #50575e;">Running v<?php echo $sysVer['ver']; ?></div>
            </div>

            <div class="wp-split">
                <!-- PAGES PANEL -->
                <div id="pages-panel" class="wp-panel active">
                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:25px;">
                        <h1 style="font-size:23px; font-weight:400; margin:0;">All Pages</h1>
                        <a href="admin.php" class="btn-wp" style="background:#fff; color:#2271b1; border-color:#2271b1;">+ Add New Page</a>
                    </div>
                    <table class="page-table">
                        <thead><tr><th>Title</th><th style="width:120px;">Date Updated</th></tr></thead>
                        <tbody>
                            <?php foreach ($allPages as $p): ?>
                            <tr>
                                <td>
                                    <div style="display:flex; align-items:center;">
                                        <a href="admin.php?edit=<?php echo $p['slug']; ?>" style="text-decoration:none; color:#2271b1; font-weight:600; font-size:14px;"><?php echo ucwords(str_replace('-', ' ', $p['slug'])); ?></a>
                                        <?php if($p['is_home'] ?? false): ?><span class="status-badge">Front Page</span><?php endif; ?>
                                    </div>
                                    <div class="row-actions">
                                        <a href="admin.php?edit=<?php echo $p['slug']; ?>">Edit</a> | 
                                        <a href="view.php?page=<?php echo $p['slug']; ?>" target="_blank">View</a> | 
                                        <a href="admin.php?delete=<?php echo $p['slug']; ?>" class="delete" onclick="return confirm('Trash this page?')">Trash</a>
                                    </div>
                                </td>
                                <td style="font-size: 12px; color: #646970;"><?php echo date('Y/m/d', strtotime($p['updated'] ?? 'now')); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- USERS PANEL -->
                <div id="users-panel" class="wp-panel">
                    <h1 style="font-size:23px; font-weight:400; margin-bottom:25px;">User Roles</h1>
                    <div style="background:#fff; border:1px solid #ccd0d4; padding:25px; margin-bottom:30px;">
                        <h4 style="margin:0 0 15px;">Add New Access Profile</h4>
                        <form method="POST">
                            <div class="form-group">
                                <label>USERNAME</label>
                                <input type="text" name="username" class="wp-input" required>
                            </div>
                            <div class="form-group">
                                <label>ROLE</label>
                                <select name="role" class="wp-input">
                                    <option>Administrator</option>
                                    <option>Normal User</option>
                                </select>
                            </div>
                            <button name="add_user" class="btn-wp">Create Profile</button>
                        </form>
                    </div>
                    <table class="page-table">
                        <thead><tr><th>User Identifier</th><th>Role</th></tr></thead>
                        <tbody>
                            <?php foreach (getAllUsers() as $u): ?>
                            <tr>
                                <td style="font-weight:600; color:#2271b1;"><?php echo $u['username']; ?></td>
                                <td style="font-size:12px;"><?php echo $u['role']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- CONFIG PANEL -->
                <div id="config-panel" class="wp-panel">
                    <h1 style="font-size:23px; font-weight:400; margin-bottom:25px;">Server Configuration</h1>
                    <div style="background:#f6f7f7; border:1px solid #ccd0d4; padding:25px; font-family:monospace; line-height:2;">
                        [CORE] INSTANCE_VER: v<?php echo $sysVer['ver']; ?><br>
                        [CORE] DATA_PATH: <?php echo __DIR__; ?>/pages_data/<br>
                        [CORE] UPLOAD_PATH: <?php echo __DIR__; ?>/uploads/<br>
                        [SECURITY] SESSION_PROTECTION: ACTIVE<br>
                        [SYSTEM] OS: Mac/Local Mirror
                    </div>
                    <div style="margin-top:30px; border:1px solid #d63638; padding:20px; border-left:4px solid #d63638;">
                        <h4 style="margin:0 0 10px; color:#d63638;">Maintenance: Version Override</h4>
                        <button class="btn-wp" style="background:#d63638; border-color:#d63638;">Force Patch Release Update</button>
                        <p style="font-size:11px; margin:10px 0 0; color:#646970;">Use only when local mirror version mismatches with production.</p>
                    </div>
                </div>

                <!-- EDITOR (FOR PAGES ONLY) -->
                <div class="wp-edit" id="editor-bar">
                    <form action="admin.php" method="POST" style="display:contents;">
                        <input type="hidden" name="current_slug" value="<?php echo $editData ? $editData['slug'] : ''; ?>">
                        <div class="edit-header">
                            <h3 style="margin:0; font-size:14px;"><?php echo $editData ? 'Editing Design' : 'Compose New'; ?></h3>
                            <button type="submit" name="create_page" class="btn-wp">Update Design</button>
                        </div>
                        <div class="edit-body">
                            <div class="form-group">
                                <label>URL DESTINATION</label>
                                <input type="text" name="slug" class="wp-input" value="<?php echo $editData ? $editData['slug'] : ''; ?>" <?php echo $editData ? 'readonly' : 'required'; ?>>
                            </div>
                            <div class="form-group">
                                <label>HTML MODULES</label>
                                <textarea name="html_content" class="wp-code wp-input"><?php echo $editData ? htmlspecialchars($editData['html']) : ''; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>STYLING (CSS)</label>
                                <textarea name="css_content" class="wp-code wp-input" style="height:150px;"><?php echo $editData ? htmlspecialchars($editData['css']) : ''; ?></textarea>
                            </div>
                            <div style="display:flex; align-items:center; gap:10px; background:#fff; padding:15px; border:1px solid #ccd0d4;">
                                <input type="checkbox" name="is_home" <?php echo ($editData && ($editData['is_home'] ?? false)) ? 'checked' : ''; ?> style="width:18px; height:18px;">
                                <label style="margin:0; font-weight:700; font-size:13px;">Landing Page Mode</label>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        function switchMainTab(id, e) {
            document.querySelectorAll('.wp-panel').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            
            document.getElementById(id + '-panel').classList.add('active');
            e.currentTarget.classList.add('active');
            
            // Hide editor if not on pages
            const editor = document.getElementById('editor-bar');
            if(id !== 'pages') { editor.style.display = 'none'; } 
            else { editor.style.display = 'flex'; }
        }
    </script>
</body>
</html>
