<?php
include 'config.php';
include 'cms_core.php';

// Access Control
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: admin.php"); exit;
}

$sysVer = getSystemVersion();
$msg = "";

// --- HANDLE FULL SYSTEM BACKUP (EXPORT) ---
if (isset($_GET['action']) && $_GET['action'] == 'export') {
    $zipName = 'full_system_backup_' . date('Y-m-d_H-i-s') . '.zip';
    $zipFile = '/tmp/' . $zipName;
    $zip = new ZipArchive;
    if ($zip->open($zipFile, ZipArchive::CREATE) === TRUE) {
        $rootPath = realpath(__DIR__);
        $files = new RecursiveIteratorIterator(new RecursiveCallbackFilterIterator(new RecursiveDirectoryIterator($rootPath, RecursiveDirectoryIterator::SKIP_DOTS), function ($file) { return !strpos($file->getRealPath(), '.DS_Store'); }), RecursiveIteratorIterator::LEAVES_ONLY);
        foreach ($files as $name => $file) { if (!$file->isDir()) { $filePath = $file->getRealPath(); $relativePath = substr($filePath, strlen($rootPath) + 1); $zip->addFile($filePath, $relativePath); } }
        $zip->close();
        header('Content-Type: application/zip'); header('Content-disposition: attachment; filename=' . $zipName); header('Content-Length: ' . filesize($zipFile));
        readfile($zipFile); unlink($zipFile); exit;
    }
}

// --- HANDLE FULL SYSTEM RESTORE (IMPORT) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['backup_zip'])) {
    $zipTmp = $_FILES['backup_zip']['tmp_name'];
    if (!empty($zipTmp)) {
        $zip = new ZipArchive;
        if ($zip->open($zipTmp) === TRUE) {
            if ($zip->extractTo(__DIR__ . '/')) { $zip->close(); bumpVersion('patch', "System Recovery Restored"); $msg = "success"; }
            else { $zip->close(); $msg = "error"; }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Backup Center - Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif; background: #f0f0f1; }
        .wp-wrapper { display: flex; height: 100vh; overflow: hidden; }
        .wp-sidebar { width: 160px; background: #26292c; display: flex; flex-direction: column; z-index: 1000; }
        .wp-sidebar a { color: #f0f0f1; text-decoration: none; padding: 12px 15px; font-size: 14px; display: block; border-left: 4px solid transparent; transition: 0.1s; }
        .wp-sidebar a:hover { background: #1d2327; color: #72aee6; }
        .wp-sidebar a.active { background: #1d2327; color: #fff; border-left-color: #72aee6; }
        .wp-main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .wp-header { height: 45px; background: #fff; border-bottom: 1px solid #ccd0d4; display: flex; align-items: center; padding: 0 20px; justify-content: space-between; }
        .wp-content { flex: 1; overflow-y: auto; background: #fff; padding: 40px; }
        .backup-card { background: #fff; border: 1px solid #ccd0d4; padding: 40px; border-radius: 4px; max-width: 800px; box-shadow: 0 1px 1px rgba(0,0,0,0.04); }
        .btn-wp { background: #2271b1; color: #fff; border: 1px solid #2271b1; padding: 10px 20px; font-size: 14px; font-weight: 600; cursor: pointer; border-radius: 3px; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
        .btn-wp:hover { background: #135e96; }
    </style>
</head>
<body>
    <div class="wp-wrapper">
        <div class="wp-sidebar">
            <div style="padding: 15px; color: #fff; font-weight: 800; font-size: 11px; opacity: 0.5;">CMS CONTROL</div>
            <a href="admin.php"><i class="fas fa-file-alt" style="width:20px;"></i> Pages</a>
            <a href="media_manager.php"><i class="fas fa-camera-retro" style="width:20px;"></i> Media</a>
            <a href="sync_center.php" class="active"><i class="fas fa-tools" style="width:20px;"></i> Backup</a>
            <a href="admin.php?tab=users"><i class="fas fa-users-cog" style="width:20px;"></i> User Roles</a>
            <a href="admin.php?tab=config"><i class="fas fa-server" style="width:20px;"></i> Server Config</a>
            <div style="margin-top: auto;">
                <a href="admin.php?logout=1" style="color: #ffa8a8;"><i class="fas fa-power-off" style="width:20px;"></i> Log Out</a>
            </div>
        </div>
        <div class="wp-main">
            <div class="wp-header">
                <div style="font-size: 13px; font-weight: 600; color: #50575e;"><i class="fas fa-tools"></i> Backup Center</div>
                <div style="font-size: 13px; color: #50575e;">Running v<?php echo $sysVer['ver']; ?></div>
            </div>
            <div class="wp-content">
                <?php if($msg == "success"): ?>
                    <div style="background:#fff; border-left:4px solid #00a32a; padding:15px; margin-bottom:30px; box-shadow:0 1px 1px rgba(0,0,0,0.04); font-size:13px;"><strong>SUCCESS!</strong> System mirror restored.</div>
                <?php endif; ?>
                <h1 style="font-size: 23px; font-weight: 400; margin: 0 0 25px;">Maintenance</h1>
                <div class="backup-card">
                    <div style="margin-bottom:30px; border-bottom:1px solid #f0f0f1; padding-bottom:30px;">
                        <h3 style="margin:0 0 10px; font-size:18px;">Full System Export</h3>
                        <p style="color:#646970; font-size:13px; line-height:1.6;">Download a complete 1:1 mirror ZIP of your today's work.</p>
                        <a href="sync_center.php?action=export" class="btn-wp"><i class="fas fa-file-archive"></i> Download .ZIP Backup</a>
                    </div>
                    <div>
                        <h3 style="margin:0 0 10px; font-size:18px;">Emergency Restore</h3>
                        <form method="POST" enctype="multipart/form-data" style="margin-top:15px;">
                            <input type="file" name="backup_zip" accept=".zip" required style="font-size:13px; margin-bottom:15px; display:block;">
                            <button type="submit" class="btn-wp" style="background:#d63638; border-color:#d63638;"><i class="fas fa-exclamation-triangle"></i> Start Restore</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
