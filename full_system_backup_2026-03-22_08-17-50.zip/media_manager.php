<?php
include 'config.php';
include 'cms_core.php';

// Access Control
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: admin.php"); exit;
}

$sysVer = getSystemVersion();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Media Library - Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif; background: #f0f0f1; }
        .wp-wrapper { display: flex; height: 100vh; overflow: hidden; }
        .wp-sidebar { width: 160px; background: #26292c; display: flex; flex-direction: column; z-index: 1000; }
        .wp-sidebar a { color: #f0f0f1; text-decoration: none; padding: 12px 15px; font-size: 14px; display: block; border-left: 4px solid transparent; transition: 0.1s; }
        .wp-sidebar a:hover { background: #1d2327; color: #72aee6; }
        .wp-sidebar a.active { background: #1d2327; color: #fff; border-left-color: #72aee6; }
        .wp-main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .wp-header { height: 45px; background: #fff; border-bottom: 1px solid #ccd0d4; display: flex; align-items: center; padding: 0 20px; justify-content: space-between; }
        .wp-content { flex: 1; overflow-y: auto; background: #fff; padding: 30px; }
    </style>
</head>
<body>
    <div class="wp-wrapper">
        <div class="wp-sidebar">
            <div style="padding: 15px; color: #fff; font-weight: 800; font-size: 11px; opacity: 0.5;">CMS CONTROL</div>
            <a href="admin.php"><i class="fas fa-file-alt" style="width:20px;"></i> Pages</a>
            <a href="media_manager.php" class="active"><i class="fas fa-camera-retro" style="width:20px;"></i> Media</a>
            <a href="sync_center.php"><i class="fas fa-tools" style="width:20px;"></i> Backup</a>
            <a href="admin.php?tab=users"><i class="fas fa-users-cog" style="width:20px;"></i> User Roles</a>
            <a href="admin.php?tab=config"><i class="fas fa-server" style="width:20px;"></i> Server Config</a>
            <div style="margin-top: auto;">
                <a href="admin.php?logout=1" style="color: #ffa8a8;"><i class="fas fa-power-off" style="width:20px;"></i> Log Out</a>
            </div>
        </div>
        <div class="wp-main">
            <div class="wp-header">
                <div style="font-size: 13px; font-weight: 600; color: #50575e;"><i class="fas fa-camera-retro"></i> Media Manager</div>
                <div style="font-size: 13px; color: #50575e;">Running v<?php echo $sysVer['ver']; ?></div>
            </div>
            <div class="wp-content">
                <h1 style="font-size:23px; font-weight:400; margin:0 0 25px;">Library</h1>
                <p>Upload and manage your assets for your site mirrors.</p>
                <!-- Add existing gallery code back here -->
            </div>
        </div>
    </div>
</body>
</html>
